﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using ChefsNDishes.Models;
using Microsoft.EntityFrameworkCore;

namespace ChefsNDishes.Controllers
{
    public class HomeController : Controller
    {
        private MyContext _context;
        public HomeController(MyContext context)
        {
            _context = context;
        }
        [HttpGet("")]
        public ViewResult Chef()
        {
            ViewBag.ChefsRoster = _context.Chefs
                .ToList();
            return View();
        }
        [HttpGet("dish")]
        public ViewResult Dish()
        {
            ViewBag.DishRoster = _context.Dishes
                // .Include(cook => cook.ChefId)
                .ToList();
            return View();
        }
        [HttpGet("newchef")]
        public ViewResult NewChef()
        {
            return View();
        }
        [HttpGet("newdish")]
        public ViewResult NewDish()
        {
            ViewBag.ChefsRoster = _context.Chefs
                .ToList();
            return View();
        }
        [HttpPost("addChef")]
        public IActionResult AddChef(Chefs newguy)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine("Model worked");
                _context.Add(newguy);
                _context.SaveChanges();
                return RedirectToAction("Chef");
            }
            Console.WriteLine("Model didn't work");
            return RedirectToAction ("AddChef");
        }
        [HttpPost("adddish")]
        public IActionResult AddDish(Dishes newPlate)
        {
            if(ModelState.IsValid)
            {
                Console.WriteLine($"Model worked. Chef's Id: {newPlate.ChefId}");
                _context.Add(newPlate);
                _context.SaveChanges();
                return RedirectToAction("Dish");
            }
            Console.WriteLine("Model didn't work");
            ViewBag.ChefsRoster = _context.Chefs
                .ToList();

            return View ("NewDish");
            // return NewDish();
        }
    }
}
