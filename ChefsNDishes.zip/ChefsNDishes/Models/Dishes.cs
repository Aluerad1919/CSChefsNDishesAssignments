using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class Dishes{
    [Key]
    public int DishId {get;set;}
    [Required]
    public string DishName {get;set;}
    [Required]
    [Range(0,Double.MaxValue)]
    public int CalCount {get;set;}
    [Required]
    public string DishDesc {get;set;}
    [Required]
    public int TasteRate {get;set;}
    [Required]
    public int ChefId {get;set;}
    public Chefs Cooks {get;set;}
    public DateTime CreatedAt {get;set;} = DateTime.Now;
    public DateTime UpdateAt {get; set;} = DateTime.Now;
}